<?php
/**
 * @package WordPress
 * @subpackage Traveler
 * @since 1.0
 *
 * Payment
 *
 * Created by ShineTheme
 *
 */
?>
<div class="pm-info">
	<p><?php echo __('Take payments via DPO payment (redirect method).', 'traveler-dpo') ?></p>
</div>