<?php
/**
 * Created by PhpStorm.
 * User: Dungdt
 * Date: 12/16/2015
 * Time: 6:01 PM
 */
?>

<div class="pm-info">
    <div class="row">
        <div class="col-sm-6">
            <div class="col-card-info">
                <div class="form-group form-group-card-country">
                    <label for="st_payulatam_country"><?php _e('Card Country', 'traveler-payulatam') ?></label>
                    <div class="controls">
                        <select class="card-country form-control select-dropdown bgr-white bottom-border input-padding"
                                name="st_payulatam_card_country"
                                id="payulatam-country" title="">
                            <option value=""><?php echo esc_html__('---- Select ----', 'traveler-payulatam'); ?></option>
                            <option
                                    value="AR"><?php echo esc_html__('Argentina', 'traveler-payulatam'); ?></option>
                            <option
                                    value="BR"><?php echo esc_html__('Brazil', 'traveler-payulatam'); ?></option>
                            <option
                                    value="CL"><?php echo esc_html__('Chile', 'traveler-payulatam'); ?></option>
                            <option
                                    value="CO"><?php echo esc_html__('Colombia', 'traveler-payulatam'); ?></option>
                            <option
                                    value="MX"><?php echo esc_html__('Mexico', 'traveler-payulatam'); ?></option>
                            <option
                                    value="PA"><?php echo esc_html__('Panama', 'traveler-payulatam'); ?></option>
                            <option
                                    value="US"><?php echo esc_html__('United States', 'traveler-payulatam'); ?></option>
                        </select>
                    </div>
                </div>
                <div class="form-group form-group-card-type">
                    <label for="st_payulatam_card_number"><?php _e('Card Type', 'traveler-payulatam') ?></label>
                    <div class="controls">
                        <select class="card-type form-control select-dropdown bgr-white bottom-border input-padding"
                                name="st_payulatam_card_type"
                                id="payulatam-type" title="">
                            <option value=""><?php echo esc_html__('---- Select ----', 'traveler-payulatam'); ?></option>
                            <option
                                    value="VISA"><?php echo esc_html__('VISA', 'traveler-payulatam'); ?></option>
                            <option
                                    value="MASTERCARD"><?php echo esc_html__('MASTERCARD', 'traveler-payulatam'); ?></option>
                            <option
                                    value="AMEX"><?php echo esc_html__('AMEX', 'traveler-payulatam'); ?></option>
                            <option
                                    value="DINERS"><?php echo esc_html__('DINERS', 'traveler-payulatam'); ?></option>
                        </select>
                    </div>
                </div>
                <div class="form-group">
                    <label for="st_payulatam_card_number"><?php _e('Card number (*)', 'traveler-payulatam') ?></label>
                    <div class="controls">
                        <input type="text" class="form-control" align="" name="st_payulatam_card_number"
                               id="st_payulatam_card_number"
                               placeholder="<?php _e('Your card number', 'traveler-payulatam') ?>">
                    </div>
                </div>
                <div class="card-code-expiry">
                    <div class="form-group expiry-date">
                        <label for="st_payulatam_card_expiry_month"><?php _e('Expiry date (*)', 'traveler-payulatam') ?></label>
                        <div class="controls clearfix">
                            <div class="form-control-wrap">
                                <select name="st_payulatam_card_expiry_month" id="st_payulatam_card_expiry_month"
                                        class="form-control app required">
                                    <optgroup label="<?php _e('Month', 'traveler-payulatam') ?>">
                                        <?php
                                        for ($i = 1; $i <= 12; $i++) {
                                            $month = sprintf('%02d', $i);
                                            printf('<option value="%s">%s</option>', $month, $month);
                                        } ?>
                                    </optgroup>
                                </select>
                            </div>
                            <div class="form-control-wrap">
                                <select name="st_payulatam_card_expiry_year" id="st_payulatam_card_expiry_year"
                                        class="form-control app required">
                                    <optgroup label="<?php _e('Year', 'traveler-payulatam') ?>">
                                        <?php
                                        $y = date('Y');
                                        for ($i = date('Y'); $i < $y + 49; $i++) {
                                            printf('<option value="%s">%s</option>', $i, $i);
                                        } ?>
                                    </optgroup>
                                </select>
                            </div>
                        </div>
                    </div>
                    <div class="form-group card-code">
                        <label for="st_payulatam_card_code"><?php _e('Card code (*)', 'traveler-payulatam') ?></label>
                        <div class="controls">
                            <input type="text" class="form-control" align="" name="st_payulatam_card_code"
                                   id="st_payulatam_card_code required">
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>